# -*- coding: utf-8 -*-

__version__ = "0.0.1"

from bribrimapper.transcriptions import transcribe_bribri_tones, bribri_to_ipa
from bribrimapper.data import tonal_transcription_map, ipa_transcription_map