=======
Credits
=======

Author and Maintainer
---------------------

* Isabella Hochschild <https://github.com/isabellahoch>

Contributors
------------

None yet. Why not be the first?
